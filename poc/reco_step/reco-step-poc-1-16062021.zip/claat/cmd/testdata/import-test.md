author: Sida Chen
summary: Import Test
id: import test

<<fragments/import-test-fragment1.md>> <!-- not going to show-->

# Sample Codelab

<<fragments/import-test-fragment1.md>> <!--not going to show-->

## Step 1

Duration 00:01:00

<<fragments/import-test-fragment1.md>>

<<fragments/import-test-fragment2.md>>

You would still need manual testing
