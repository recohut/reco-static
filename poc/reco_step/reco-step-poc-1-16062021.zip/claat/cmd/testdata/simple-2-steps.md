author: Marc DiPasquale
summary: Create a CodeLab Using Markdown
id: example
categories: codelab,markdown
environments: Web
status: Published
feedback link: https://github.com/Mrc0113/codelab-4-codelab

# Sample Codelab

## Step 1

Duration 00:01:00

Content 1

## Step 2

Duration 00:02:00

Content 2
